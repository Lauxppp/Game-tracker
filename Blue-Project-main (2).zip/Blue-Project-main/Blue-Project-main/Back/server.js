//IMPORTACION DE BIBLIOTECAS Y CREACIÓN DE CONSTANTES
require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const app = express(); 
const PORT = process.env.PORT || 3000;
const MONGODB_URL = process.env.MONGODB_URL;

app.use(express.json());

//CONEXIÓN CON LA BASE DE DATOS
mongoose.connect(MONGODB_URL)
    .then(() => {
        console.log('Conexión exitosa a MongoDB Atlas');
   })
.catch(err => {
    console.log('Error de conexión', err.message);
    process.exit(1);
})

//RUTAS
//ABCDEFGHIJKLMNOPQRTUVWXYZ

app.listen(PORT, () => {
    console.log(`Servidor Corriendo en http://localhost:${PORT}`)
})